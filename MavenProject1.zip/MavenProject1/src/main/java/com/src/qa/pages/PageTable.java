package com.src.qa.pages;

import java.io.IOException;

import com.src.qa.base.BaseClass;

public class PageTable extends BaseClass{

	public PageTable() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
