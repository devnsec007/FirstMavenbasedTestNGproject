package com.src.qa.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelDataReader {

	
	
	//FileInputStream ExcelFile = new FileInputStream("C:\\Users\\DB\\eclipse-workspace\\MavenProject1\\src\\test\\resources\\TestData\\MasterDS.xlsx");
	public static FileInputStream ExcelFile;
	public static Workbook Book;
	public static Sheet Wsheet;
	
	
	public static Object[][] ExcelReader(String SheetName){
		
		try {
			ExcelFile = new FileInputStream("C:\\Users\\DB\\eclipse-workspace\\MavenProject1\\src\\test\\resources\\TestData\\MasterDS.xlsx");
			try {
				 Book = WorkbookFactory.create(ExcelFile);
			} catch (EncryptedDocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Wsheet = Book.getSheet(SheetName);
		
		 Object[][] OBArray = new Object[Wsheet.getLastRowNum()][Wsheet.getRow(0).getLastCellNum()];
		 
		 
		 for(int i=0;i<Wsheet.getLastRowNum();i++) {
			 
			 for(int j =0;j<Wsheet.getRow(0).getLastCellNum();j++) {
				 
				 OBArray[i][j] = Wsheet.getRow(i+1).getCell(j).toString();
				 
			 }
			 
			 
		 }
		 
		 
		
		return OBArray;
		
	}
	
	
	
	
	
	
}
