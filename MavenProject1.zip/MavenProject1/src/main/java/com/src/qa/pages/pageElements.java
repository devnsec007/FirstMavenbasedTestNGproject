package com.src.qa.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.src.qa.base.BaseClass;

public class pageElements extends BaseClass{



			
	
	 @FindBy(id="userName-label")
	 WebElement IDLevel;
	 
	 @FindBy(id="userName")
	 WebElement IDinputBox;
	 
	@FindBy(xpath = "//div[@class='card-body']/h5[contains(text(),'Elements')]/parent::div/parent::div/parent::div")
	WebElement ElementsLink;
	 
	 public String GetTitleText() {
		 
		 return driver.getTitle();
		 
	 }
	 
	 public boolean UserNameLebelExist() {
		 
		 
		 return IDLevel.isDisplayed();
		 
	 }
	 
	 public void NavigateElements() {
		 
		 ElementsLink.click();
		 
	 }
	 
	 
	 
		public pageElements() throws IOException{
			super();
			
			PageFactory.initElements(driver, this);
			// TODO Auto-generated constructor stub
			
			
		}
	 
	 
}
