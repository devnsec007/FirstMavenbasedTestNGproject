package com.src.qa.utilities;

public class TestUtility extends ExcelDataReader{

	
static TestUtility TU = new TestUtility();
	
	
	public Object[][] ArrayValueReturn(){
		
		Object[][] OARRAY = TU.ExcelReader("InputBoxSource");
		
		
		return OARRAY;
	};
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Object[][] matrix = TU.ArrayValueReturn();
		
		for (int i = 0; i < matrix.length; i++) { //this equals to the row in our matrix.
	         for (int j = 0; j < matrix[i].length; j++) { //this equals to the column in each row.
	            System.out.print(matrix[i][j] + " ");
	         }
	         System.out.println(); //change line on console as row comes to end in the matrix.
	      }
		
	}

}



