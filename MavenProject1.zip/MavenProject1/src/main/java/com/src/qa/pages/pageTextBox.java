package com.src.qa.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.src.qa.base.BaseClass;

public class pageTextBox extends BaseClass{

	public pageTextBox() throws IOException {
		super();
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//span[@class='text'][contains(text(),'Text Box')]")
	WebElement TextboxLink ;
	
	@FindBy(xpath="//input[@id='userName']")
	WebElement UserNameInputBox ;
	
	@FindBy(xpath="//input[@id='userEmail']")
	WebElement UserEmailInputBox ;
	
	@FindBy(xpath="//textarea[@id='currentAddress']")
	WebElement UserCurrentAddressInputBox ;
	
	
	@FindBy(xpath="//textarea[@id='permanentAddress']")
	WebElement UserPermanentAddressInputBox ;
	
	@FindBy(xpath="//button[@id='submit']")
	WebElement SubmitButton ;
	
	public void NavigateToTextBoxPage() {
		
		TextboxLink.click();
		
		
	}
	
	public String checkTextBoxPageURL() {
		
		return driver.getCurrentUrl();
		
	}
	
	
	
	
	public void EnterTextData(String Name, String email, String CAddress, String PAddress ) {
		
		UserNameInputBox.clear();
		UserNameInputBox.sendKeys(Name);
		
		UserEmailInputBox.clear();
		UserEmailInputBox.sendKeys(email);
		
		UserCurrentAddressInputBox.clear();
		UserCurrentAddressInputBox.sendKeys(CAddress);
		
		UserPermanentAddressInputBox.clear();
		UserPermanentAddressInputBox.sendKeys(PAddress);
		
	}
	
	public void EnTerSubmitButton() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,10000)");
		
		Actions AS = new Actions(driver);
		AS.moveToElement(SubmitButton).click().build().perform();
		
		
	}
	
	
	
	
}
