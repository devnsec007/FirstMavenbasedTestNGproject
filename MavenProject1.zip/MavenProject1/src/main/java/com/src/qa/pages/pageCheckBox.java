package com.src.qa.pages;

import java.io.IOException;

import com.src.qa.base.BaseClass;

public class pageCheckBox extends BaseClass{

	public pageCheckBox() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

}
