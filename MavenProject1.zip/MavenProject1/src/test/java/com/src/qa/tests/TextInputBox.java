package com.src.qa.tests;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.*;


import com.src.qa.base.BaseClass;
import com.src.qa.pages.pageElements;
import com.src.qa.pages.pageTextBox;
import com.src.qa.utilities.ExcelDataReader;

public class TextInputBox extends BaseClass{

	pageElements PageElimentsObj;
	pageTextBox pageTextBoxobj;
	ExcelDataReader ExcelDataReaderObj;
	
	
	public TextInputBox() throws IOException {
		super();
		// TODO Auto-generated constructor stub
		
	}
	
	@BeforeMethod
	public void Setup() {
		
		initialization();
		
		try {
			PageElimentsObj = new pageElements();
			pageTextBoxobj = new pageTextBox();
			ExcelDataReaderObj=new ExcelDataReader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		PageElimentsObj.NavigateElements();
		pageTextBoxobj.NavigateToTextBoxPage();
		
	}
	
	@DataProvider
	public Object[][] TestDataProvider() {
		
		Object[][] ExcelData =  ExcelDataReaderObj.ExcelReader("InputBoxSource");
		return ExcelData;
		
		
		
	}
	
	
	
	
	@Test(priority = 1)
	public void TestTheInputTextBoxURL() {
		
		Assert.assertEquals(pageTextBoxobj.checkTextBoxPageURL().toString(),"https://demoqa.com/text-box");
		
		
	}
	
	
	
	
	@Test(priority = 2, dataProvider = "TestDataProvider")
	public void TestDataEntryTextBox(String Name,String email,String CAddress,String PAddress) {
		
		pageTextBoxobj.EnterTextData(Name, email, CAddress, PAddress);
		pageTextBoxobj.EnTerSubmitButton();
		
		
			
	}
	
	
	
	
	@AfterMethod
	public void TearDown() {
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}

}
